<?php
// functions moved in class / wpestate_email
?>